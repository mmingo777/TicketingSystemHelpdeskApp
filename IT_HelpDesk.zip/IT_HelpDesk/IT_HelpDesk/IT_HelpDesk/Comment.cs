﻿using System;

namespace IT_HelpDesk
{
    public class Comment
    {
        public string Author { get; set; }
        public string Message { get; set; }
        public DateTime Timestamp { get; set; }
    }
}

